import { Link, useLocation } from 'react-router-dom';
import { Globe } from 'lucide-react';

export function Header() {
  const location = useLocation();
  
  return (
    <header className="bg-white border-b border-gray-200">
      <div className="max-w-6xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Globe className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl text-gray-900">LinguaSchool</span>
          </Link>
          
          <nav className="flex gap-8">
            <Link 
              to="/" 
              className={`text-sm transition-colors ${
                location.pathname === '/' 
                  ? 'text-blue-600' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Inicio
            </Link>
            <Link 
              to="/contacto" 
              className={`text-sm transition-colors ${
                location.pathname === '/contacto' 
                  ? 'text-blue-600' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Contacto
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
