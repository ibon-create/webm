import { Header } from './Header';
import { Hero } from './Hero';
import { BookOpen, Users, Award, Clock } from 'lucide-react';

const services = [
  {
    icon: BookOpen,
    title: 'Clases Personalizadas',
    description: 'Adaptamos el contenido a tus objetivos y nivel de conocimiento.'
  },
  {
    icon: Users,
    title: 'Grupos Reducidos',
    description: 'Máximo 8 estudiantes por clase para garantizar atención individualizada.'
  },
  {
    icon: Award,
    title: 'Certificaciones Oficiales',
    description: 'Preparación para exámenes DELE, TOEFL, Cambridge y más.'
  },
  {
    icon: Clock,
    title: 'Horarios Flexibles',
    description: 'Clases por la mañana, tarde y noche adaptadas a tu agenda.'
  }
];

const testimonials = [
  {
    name: 'María González',
    role: 'Estudiante de Inglés',
    content: 'En 6 meses conseguí el nivel B2 que necesitaba. Los profesores son excelentes y las clases muy dinámicas.',
    rating: 5
  },
  {
    name: 'Carlos Martín',
    role: 'Estudiante de Alemán',
    content: 'La metodología es muy práctica y efectiva. Desde la primera clase empiezas a hablar el idioma.',
    rating: 5
  },
  {
    name: 'Ana Rodríguez',
    role: 'Estudiante de Francés',
    content: 'El ambiente es muy acogedor y los grupos pequeños permiten avanzar rápidamente. Totalmente recomendable.',
    rating: 5
  }
];

export function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <Hero 
        title="Aprende idiomas con confianza"
        subtitle="Clases personalizadas con profesores nativos. Alcanza tus objetivos lingüísticos de manera efectiva y natural."
        imageUrl="https://images.unsplash.com/photo-1558443957-d056622df610?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYW5ndWFnZSUyMGxlYXJuaW5nJTIwY2xhc3Nyb29tfGVufDF8fHx8MTc2ODEzODcxMnww&ixlib=rb-4.1.0&q=80&w=1080"
        showCTA={true}
      />

      {/* Servicios */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4 text-gray-900">Nuestros Servicios</h2>
            <p className="text-xl text-gray-600">Todo lo que necesitas para dominar un nuevo idioma</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <div 
                  key={index} 
                  className="p-6 rounded-xl border border-gray-200 hover:border-blue-600 transition-colors"
                >
                  <div className="bg-blue-50 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl mb-2 text-gray-900">{service.title}</h3>
                  <p className="text-gray-600">{service.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Opiniones de Clientes */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4 text-gray-900">Lo que dicen nuestros estudiantes</h2>
            <p className="text-xl text-gray-600">Historias de éxito reales</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div 
                key={index} 
                className="bg-white p-8 rounded-xl border border-gray-200"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <svg 
                      key={i} 
                      className="w-5 h-5 text-yellow-400 fill-current"
                      viewBox="0 0 20 20"
                    >
                      <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
                    </svg>
                  ))}
                </div>
                <p className="text-gray-700 mb-6 italic">"{testimonial.content}"</p>
                <div>
                  <p className="text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-8">
        <div className="max-w-6xl mx-auto px-6 text-center text-gray-600">
          <p>© 2026 LinguaSchool. Todos los derechos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
