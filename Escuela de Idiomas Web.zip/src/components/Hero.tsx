import { ImageWithFallback } from './figma/ImageWithFallback';

interface HeroProps {
  title: string;
  subtitle: string;
  imageUrl: string;
  showCTA?: boolean;
}

export function Hero({ title, subtitle, imageUrl, showCTA = false }: HeroProps) {
  return (
    <section className="relative bg-gray-50">
      <div className="max-w-6xl mx-auto px-6 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl mb-6 text-gray-900">{title}</h1>
            <p className="text-xl text-gray-600 mb-8">{subtitle}</p>
            {showCTA && (
              <button className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors">
                Reserva tu clase de prueba
              </button>
            )}
          </div>
          <div className="relative h-[400px] rounded-2xl overflow-hidden">
            <ImageWithFallback 
              src={imageUrl}
              alt="Hero"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
