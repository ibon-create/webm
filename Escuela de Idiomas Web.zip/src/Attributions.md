Este archivo de Figma Make incluye componentes de [shadcn/ui](https://ui.shadcn.com/) utilizados bajo [licencia MIT](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md).

Este archivo de Figma Make incluye fotos de [Unsplash](https://unsplash.com) usadas bajo [licencia](https://unsplash.com/license).