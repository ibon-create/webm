
  # Escuela de Idiomas Web

  This is a code bundle for Escuela de Idiomas Web. The original project is available at https://www.figma.com/design/wuVrn8UHHE7xGkkY9VHbmu/Escuela-de-Idiomas-Web.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  